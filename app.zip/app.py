from flask import Flask, render_template, request, redirect, url_for, session,send_from_directory,jsonify
from flask_mysqldb import MySQL
from flask_mail import Mail, Message
import json
import joblib
import numpy as np
import pandas as pd

app = Flask(__name__, template_folder='template')
app.secret_key = 'Hari@2001'  # Set a secret key for session management

# Configure MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Hari@2001'
app.config['MYSQL_DB'] = 'aml'

mysql = MySQL(app)

# Configure Flask-Mail
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'harikrishnanvb.mail@gmail.com'  # Your Gmail address
app.config['MAIL_PASSWORD'] = 'qtck yvot bwgz ttrd'        # Your Gmail password
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True

# Initialize Flask-Mail and MySQL
mail = Mail(app)

 #NAME_NATIONALITY LIST
data = pd.read_csv(r"C:\Users\vickr\OneDrive\Desktop\MAJOR _PROJECT\DATASET\namelist.csv")
names_list = data['fname'].str.split().str[0].tolist()
name_nationality_dict = {}



for index, row in data.iterrows():
    name = row['fname'].split()[0]
nationality = row['nationality']
name_nationality_dict[name] = nationality


print(name_nationality_dict)



@app.route('/')
def index():
    message = request.args.get('message')
    return render_template('Mainpage.html', message=message)
@app.route('/register', methods=['POST'])
def register():
    if request.method == 'POST':
        userDetails = request.form
        userType = userDetails.get('user-type')
        if userType == 'bank':
            # Extract common user details
            uid = userDetails.get('uid')
            username = userDetails.get('bank-username')
            password = userDetails.get('bank-password')
            contact_number = userDetails.get('bank-contact-number')
            emailid = userDetails.get('bank-email')

            # Insert common user details into aml_user table
            cur = mysql.connection.cursor()
            try:
                cur.execute("""
                    INSERT INTO aml_user (uid, username, password, contact_number, emailid, userrole) 
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """, (uid, username, password, contact_number, emailid, userType))
                mysql.connection.commit()
                user_id = cur.lastrowid

                # Insert bank specific details into aml_bankdetails table
                bank_id = userDetails.get('bank-id')
                bank_name = userDetails.get('bank-name')
                bank_branch = userDetails.get('bank-branch')
                bank_address = userDetails.get('bank-address')

                cur.execute("""
                    INSERT INTO aml_bankdetails 
                    (bankid, bankuid, bank_name, bank_branch, bank_address, bank_contactnumber, bank_emailid, bank_username, bank_password,userrole) 
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s,%s)
                    """, (bank_id, user_id, bank_name, bank_branch, bank_address, contact_number, emailid, username, password,userType))
                mysql.connection.commit()

                return redirect(url_for('index', message='Registration successful'))
            except mysql.connection.IntegrityError as e:
                print(f"Error inserting user or bank details: {e}")
                mysql.connection.rollback()
            finally:
                cur.close()

        elif userType == 'customer':
            # Extract common user details
            uid = userDetails.get('uid')
            username = userDetails.get('customer-username')
            password = userDetails.get('customer-password')
            contact_number = userDetails.get('customer-contact-number')
            emailid = userDetails.get('customer-email')

            # Insert common user details into aml_user table
            cur = mysql.connection.cursor()
            try:
                cur.execute("""
                    INSERT INTO aml_user (uid, username, password, contact_number, emailid, userrole) 
                    VALUES (%s, %s, %s, %s, %s, %s)
                    """, (uid, username, password, contact_number, emailid, userType))
                mysql.connection.commit()
                user_id = cur.lastrowid

                # Insert customer specific details into aml_customeraccountdetails table
                customer_id = userDetails.get('customer-id')
                customer_name = userDetails.get('customer-name')
                customer_dob = userDetails.get('customer-dob')
                customer_address = userDetails.get('customer-address')
                customer_nationality = userDetails.get('customer-nationality')
                customer_account_details = userDetails.get('customer-account-details')
                customer_accounttype = userDetails.get('customer-accounttype')
                customer_accountname = userDetails.get('customer-accountname')
                customer_currentbalance = userDetails.get('customer-currentbalance')
                customer_bankname = userDetails.get('customer-bankname')

                cur.execute("""
                    INSERT INTO aml_customeraccountdetails 
                    (customerid, customeruid, customer_name, customer_dob, customer_address, customer_nationality, 
                    customer_contactnumber, customer_accountdetails, customer_emailid,customer_username,customer_password, customer_accounttype, 
                    customer_accountname, customer_currentbalance, customer_bankname,userrole) 
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s,%s,%s)
                    """, (customer_id, user_id, customer_name, customer_dob, customer_address, customer_nationality, 
                          contact_number, customer_account_details, emailid,username,password, customer_accounttype, 
                          customer_accountname, customer_currentbalance, customer_bankname,userType))
                mysql.connection.commit()

                return redirect(url_for('index', message='Registration successful'))
            except mysql.connection.IntegrityError as e:
                print(f"Error inserting user or customer details: {e}")
                mysql.connection.rollback()
            finally:
                cur.close()

    return 'Registration failed. Please try again.'

########################################################################

@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM aml_user WHERE username = %s AND  password = %s", (username, password))
        userrole = cur.fetchone()
        print(">>>>>>>>>>>>>>>>>>>>>.",userrole,type(userrole),userrole[0])
        #cur.execute("SELECT * FROM aml_customeraccountdetails WHERE customer_username = %s AND customer_password = %s", (username, password))
        #customer_user = cur.fetchone()
        cur.close()

        #for user in userrole:
            #print(user)
    if userrole is not None:
        if userrole[5] == 'bank':
            print("bank")
            session['userrole'] = userrole[5]
            return redirect(url_for('bank_home'))
        
        elif userrole[5] == 'customer':
            print("customer")
            session['userrole'] = userrole[5]
            return redirect(url_for('customer_home'))
            
            
        elif userrole[5] == 'officer':
            print("officer")
            session['userrole']=userrole[5]
            return redirect(url_for('officer_home'))


        
        else:
            print("elseeeeeeeeeeee",userrole[5])
            return redirect(url_for('index', message='Incorrect username or password. Reset it below.'))
        

        ##############################################################################################


@app.route('/add', methods=['POST'])
def add():
    from werkzeug.datastructures import ImmutableMultiDict
    if request.method == 'POST':
        userDetails = request.form.to_dict()  # Get form data as a dictionary
        print(type(userDetails), "<<<<<<<<<<<<>>>>>>>>>>>>>>>>>", userDetails)
        userType = 'officer'

        # Extract common user details
        uid = userDetails.get('uid')
        username = userDetails.get('username')
        password = userDetails.get('password')
        contact_number = userDetails.get('officer_contactnumber')
        emailid = userDetails.get('officer_emailid')

        # Insert common user details into aml_user table
        cur = mysql.connection.cursor()
        try:
            cur.execute("""
                INSERT INTO aml_user (uid,username, password, contact_number, emailid, userrole) 
                VALUES (%s, %s, %s, %s, %s,%s)
            """, (uid, username, password, contact_number, emailid, userType))
            mysql.connection.commit()

            officeruid = cur.lastrowid

        except mysql.connection.IntegrityError as e:
            print(f"Error inserting bank details: {e}")
            mysql.connection.rollback()
            cur.close()
            return redirect(url_for('index', message='Registration failed'))
        finally:
            cur.close()  # Close cursor even on exceptions
        userType='officer'
        # Extract officer details (retrieve here)
        officer_id = userDetails.get('officerid')
        officer_name = userDetails.get('officer_name')
        officer_dob = userDetails.get('officer_dob')
        officer_address = userDetails.get('officer_address')

        print("ooooooo", officer_name)  # Print officer name for verification

        # Insert officer details into aml_officerregistration table
        cur = mysql.connection.cursor()
        try:
            print("try block")
            cur.execute("""
                INSERT INTO aml_officerregistration 
                (officerid, officeruid,officer_name, officer_dob, officer_address, officer_contactnumber, officer_emailid, officer_username, officer_password,userrole)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s,%s)
            """, (officer_id, officeruid, officer_name, officer_dob, officer_address, contact_number, emailid, username, password,userType))
            mysql.connection.commit()

            # Send email after successful registration
            msg = Message('AI- AML Screening',
                          sender=app.config['MAIL_USERNAME'],
                          recipients=[emailid])
            msg.body = f' Hello {officer_name} \n\n We are from AI- AML Screening Software Solutions,\n\nYour account registration for the role aml officer account was successful. \n\nBelow is your credentials to login to your account \n\nUsername: {username}\n\nPassword: {password}\n\n Thank you!\n\n Team AI- AML Screening'
            mail.send(msg)

            cur.close()
            return redirect(url_for('bank_home', message='Registration successful'))

        except mysql.connection.IntegrityError as e:
            print("exception block")
           # print("aaaaaaaaaaaaaaaaaaa")
            print(f"Error inserting officer details: {e}")
            mysql.connection.rollback()
            cur.close()
            return redirect(url_for('index', message='Registration failed. Officer ID may already exist.'))



        ######################################################################################################
@app.route('/transfer', methods=['POST'])
def transfer():
    if request.method == 'POST':
        transaction_id = request.form.get('transactionid')
        customer_id = request.form.get('customerid')
        customer_name = request.form.get('transaction_customername')
        customer_dob = request.form.get('transaction_customerdob')
        customer_nationality = request.form.get('transaction_customernationality')
        customer_acc_no = request.form.get('transaction_customeraccno')
        transaction_amount = request.form.get('transaction_amount')
        recipient_name = request.form.get('transaction_reciepientname')
        recipient_nationality = request.form.get('transaction_reciepientnationality')
        recipient_acc_no = request.form.get('transaction_reciepientaccno')
        bank_name = request.form.get('transaction_bankname')
        branch_name = request.form.get('transaction_branchname')
        account_number = request.form.get('transaction_accountnumber')
        transaction_date_time = request.form.get('transaction_dateandtimeoftranscation')
        type = request.form.get('type')
        amount = request.form.get('amount')
        oldbalanceOrg = request.form.get('oldbalanceOrg')
        newbalanceOrig = request.form.get('newbalanceOrig')
        oldbalanceDest = request.form.get('oldbalanceDest')
        newbalanceDest = request.form.get('newbalanceDest')
        isFraud = request.form.get('isFraud')
        
        cur = mysql.connection.cursor()
        try:
            cur.execute("""
                INSERT INTO aml_transaction
                (transactionid, customerid, transaction_customername, transaction_customerdob, transaction_customernationality, transaction_customeraccno, transaction_amount, transaction_reciepientname, transaction_reciepientnationality, transaction_reciepientaccno, transaction_bankname, transaction_branchname, transaction_accountnumber, type, amount, oldbalanceOrg, newbalanceOrig, oldbalanceDest, newbalanceDest, isFraud, transaction_dateandtimeoftranscation)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (transaction_id, customer_id, customer_name, customer_dob, customer_nationality, customer_acc_no, transaction_amount, recipient_name, recipient_nationality, recipient_acc_no, bank_name, branch_name, account_number, type, amount, oldbalanceOrg, newbalanceOrig, oldbalanceDest, newbalanceDest, isFraud, transaction_date_time))

            mysql.connection.commit()
            cur.close()
            return redirect(url_for('customer_home', message='Transfer successful'))
        except mysql.connection.IntegrityError as e:
            print(f"Error inserting transaction details: {e}")
            mysql.connection.rollback()
            cur.close()
            return redirect(url_for('index', message='Transfer failed. Check your details and try again.'))


       #######################################################################################################
        
@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    if request.method == 'POST':
        cfid = request.form.get('cfid')
        customerid = request.form.get('customerid')
        customer_suggestion = request.form.get('customer_suggestion')
        customer_feedback = request.form.get('customer_feedback')

        cur = mysql.connection.cursor()
        try:
            cur.execute("""
                INSERT INTO aml_customerfeedback
                (cfid, customerid, customer_suggestion, customer_feedback)
                VALUES (%s, %s, %s, %s)
                """,
                (cfid, customerid, customer_suggestion, customer_feedback))
            mysql.connection.commit()
            cur.close()
            return redirect(url_for('customer_home', message='Feedback submitted successfully'))
        except mysql.connection.IntegrityError as e:
            print(f"Error inserting feedback details: {e}")
            mysql.connection.rollback()
            cur.close()
            return redirect(url_for('index', message='Feedback submission failed. Please try again.'))




        ######################################################################################################



@app.route('/view_transaction')
def view_transaction():
    conn = mysql.connection
    cur = conn.cursor()

    cur.execute("SELECT * FROM aml_transaction")
    transactions = cur.fetchall()

    print(transactions)

    cur.close()

    return render_template('bank_viewtransactions.html', transactions=transactions)

        ######################################################################################################

@app.route('/managecustomer')
def managecustomer():
    conn = mysql.connection
    
    cur = conn.cursor()

    cur.execute ("SELECT * FROM aml_customeraccountdetails")
    transactions= cur.fetchall()

    print(transactions)

    cur.close()

    return render_template('bank_managecustomers.html', transactions=transactions)

###############################################################################################################
@app.route('/feedback')
def feedback():
    conn = mysql.connection
    cur = conn.cursor()

    cur.execute("SELECT * FROM aml_customerfeedback")
    transactions = cur.fetchall()

    print(transactions)

    cur.close()

    return render_template('bank_viewfeedback.html', transactions=transactions)


###############################################################################################################

#######################################
import pickle

label_encoder = None
# label_encoder = joblib.load('type_encoded.pkl')
with open(r"C:\\Users\\vickr\\OneDrive\\Desktop\\MAJOR _PROJECT\\PROJECT_MODEL\\type_encoded.pkl", 'rb') as f:
    label_encoder = pickle.load(f)
    ##############################################################
@app.route('/customer_viewtransaction')
def customer_viewtransaction():
    conn = mysql.connection
    cur = conn.cursor()

    cur.execute("SELECT * FROM aml_transaction")
    transactions= cur.fetchall()

    print(transactions)

    cur.close()

    return render_template('customer_viewtransactions.html', transactions=transactions)
################################################################################################################


@app.route('/officer_viewtransaction')
def officer_viewtransaction():
    conn = mysql.connection
    cur = conn.cursor()

    cur.execute("SELECT * FROM aml_transaction")
    transactions= cur.fetchall()

    print(transactions)

    cur.close()

    return render_template('officer_viewtransactions.html', transactions=transactions)
################################################################################################################

@app.route('/bank')
def bank_home():
    return render_template('bank.html')


@app.route('/customer')
def customer_home():
    return render_template('customer.html')



@app.route('/officer')
def officer_home():
    return render_template('officer.html')


# def customer_home():
#     if 'username' in session:
#         return render_template('customer.html')
#     return redirect(url_for('index'))

# Route for resetting the password
@app.route('/reset-password', methods=['POST'])
def reset_password():
    # Logic to update the password in the database would go here
    # For this example, let's assume the password was successfully reset
    return "Password reset successful. Please log in with your new password."
#####################################################################################################################
#CUSTOMER MODULE

@app.route('/customerprofile.html')
def profile():
    return send_from_directory('template', 'customerprofile.html')


@app.route('/customer_maketransactions.html')
def make_transaction():
    return send_from_directory('template', 'customer_maketransactions.html')


@app.route('/customer_viewtransactions.html')
def view_transactions():
    return send_from_directory('template', 'customer_viewtransactions.html')


@app.route('/customer_bankdetails.html')
def bank_details():
    return send_from_directory('template', 'customer_bankdetails.html')

@app.route('/customer_providefeedback.html')
def provide_feedback():
    return send_from_directory('template', 'customer_providefeedback.html')

@app.route('/index.html')
def logout_customer():
   return redirect(url_for('index'))
################################################################################################################################

@app.route('/officer_bankdetails.html')
def officer_bankdetails():
    return send_from_directory('template', 'officer_bankdetails.html')


@app.route('/officer_viewcustomers.html')
def officer_viewcustomers():
    return send_from_directory('template', 'officer_viewcustomers.html')


@app.route('/officer_viewtransactions.html')
def officer_viewtransactions():
    return send_from_directory('template', 'officer_viewtransactions.html')

@app.route('/officer_suspectlist.html')
def officer_suspectlist():
    return send_from_directory('template', 'officer_suspectlist.html')

@app.route('/index.html')
def logout_officer():
   return redirect(url_for('index'))
################################################################################################################################
# @app.route('/result')
# def result():
#     return render_template('result.html')



################################################################################################################################

#BANK MODULE 
@app.route('/bank_addofficer.html')
def add_officer():
    return send_from_directory('template', 'bank_addofficer.html')


@app.route('/bank_managecustomers.html')
def manage_customer():
    return send_from_directory('template', 'bank_managecustomers.html')


@app.route('/bank_viewtransactions.html')
def bank_viewtransactions():
    return send_from_directory('template', 'bank_viewtransactions.html')


@app.route('/bank_suspectlist.html')
def suspect_list():
    return send_from_directory('template', 'bank_suspectlist.html')

@app.route('/bank_viewfeedback.html')
def view_feedback():
    return send_from_directory('template', 'bank_viewfeedback.html')

@app.route('/index.html')
def logout_bank():
   return redirect(url_for('index'))
#################################################################################################
@app.route('/get_started')
def get_started():
    # Here you can put any processing logic before redirecting
     return render_template('index.html')

################################################################################################

import joblib

# Dummy prediction function for demonstration
def ValuePredictor(to_predict_list):
    # Assuming you have defined label_encoder
    with open(r"C:\Users\vickr\OneDrive\Desktop\MAJOR _PROJECT\PROJECT_MODEL\fraud_detection.joblib", 'rb') as f:
    #  with open(r"C:\Users\vickr\OneDrive\Desktop\MAJOR _PROJECT\PROJECT_MODEL\risk_prediction.joblib", 'rb') as f:
        loaded_model = joblib.load(f)  # Load the model using joblib
    result = loaded_model.predict(np.array(to_predict_list).reshape(1, -1))
    return result[0]

def Riskprediction(to_black_list):
    # Assuming you have defined label_encoder
    with open(r"C:\Users\vickr\OneDrive\Desktop\MAJOR _PROJECT\PROJECT_MODEL\risk_prediction.joblib", 'rb') as f:
        loaded_model = joblib.load(f)  # Load the model using joblib
    result = loaded_model.predict(np.array(to_black_list).reshape(1, -1))
    return result[0]

@app.route('/')
def home():
    transactions=[]
    # Render the initial HTML page with transaction details
    # You can pass the transactions data to the template if needed
    return render_template("viewtransactions.html", transactions=transactions)

@app.route('/result', methods=['POST'])
def result():
    if request.method == 'POST':
        # Extract form data
        feature_1 = request.form.get('feature_1')#TYPE
        feature_2 = float(request.form.get('feature_2'))#Amount
        feature_3 = float(request.form.get('feature_3'))#Sender Old Balance
        feature_4 = float(request.form.get('feature_4'))#Sender New Balance
        feature_5 = float(request.form.get('feature_5'))#Reciever Old Balance
        feature_6 = float(request.form.get('feature_6'))#Reciever New Balance
        feature_7 = request.form.get('feature_7')#Name
        feature_8 = request.form.get('feature_8')#Nationality
        feature_9=request.form.get('feature_9')#Risk Rating
        feature_10=request.form.get('featutre_10')#rate_source
        feature_11=request.form.get('feature_11')#risk_assessment
         



    


        # Process form data
        # Assuming you have defined label_encoder
        feature_1_enc = label_encoder.transform([feature_1])
        feature_8_enc = label_encoder.transform([feature_8])
        feature_10_enc = label_encoder.transform([feature_10])


        if feature_7 in names_list:
          
           if name_nationality_dict.get(feature_7) is None:
            print("Black listed")
            return jsonify({'prediction': 'Black listed'})
        
        elif name_nationality_dict.get(feature_8) is not None:
            print("High risk")
            to_black_list = [feature_2,feature_9,feature_10_enc[0],feature_11_enc[0]]
            result = Riskprediction(to_black_list)

            # Determine prediction result
            prediction = 'High Risk' if result ==0 else 'Low Risk' if result ==1 else 'Medium Risk'
            if result==0:
             return jsonify({'prediction':prediction}) 
            else:
                 to_predict_list = [feature_1_enc[0], feature_2, feature_3, feature_4, feature_5, feature_6,feature_8]
                 result = ValuePredictor(to_predict_list)

                 prediction = 'Transaction is Fraud' if result == 1 else 'Transaction is not fraud'
                  # Return prediction as JSON
            return jsonify({'prediction': prediction})
            
        else:
            return "Method not allowed", 405
        
        

    #     # Make prediction
    #     to_predict_list = [feature_1_enc[0], feature_2, feature_3, feature_4, feature_5, feature_6,feature_7_enc[0],feature_8_enc[0]]
    #     result = ValuePredictor(to_predict_list)

    

    #     # Determine prediction result
    #     prediction = 'Transaction is Fraud' if result == 1 else 'Transaction is not fraud'
        
    #     # Return prediction as JSON
    #     return jsonify({'prediction': prediction})
    # else:
    #     return "Method not allowed", 405



#################################################################################################

if __name__ == '__main__':
    app.run(debug=True)
